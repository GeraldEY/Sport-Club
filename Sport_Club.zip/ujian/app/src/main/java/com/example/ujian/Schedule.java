package com.example.ujian;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Schedule {

        String tim1,tim2,waktu,tanggal,judul,harga;
        int gambar_1 ,gambar_2;

        public Schedule(String tim1,String tim2,String waktu,String tanggal,String judul,String harga,int gambar_1,int gambar_2){
            this.tim1= tim1;
            this.tim2 = tim2;
            this.waktu = waktu;
            this.tanggal = tanggal;
            this.judul = judul;
            this.harga = harga;
            this.gambar_1 = gambar_1;
            this.gambar_2 = gambar_2;



        }
        public String getTim1() {
            return tim1;
        }

        public void setTim1(String tim1) {
            this.tim1 = tim1;
        }

        public int getGambar_1() {
            return gambar_1;
        }

        public void setGambar_1(int gambar_1) {
            this.gambar_1 = gambar_1;
        }

        public int getGambar_2(){
            return gambar_2;
        }

        public void setGambar_2(int gambar_2) {
            this.gambar_2 = gambar_2;
        }

        public String getTim2() {
            return tim2;
        }

        public void setTim2(String tim2) {
            this.tim2 = tim2;
        }

        public String getJudul() {
        return judul;
    }

        public void setJudul(String judul) {
        this.judul = judul;
    }
        public String getHarga() {
        return harga;
    }

        public void setHarga(String harga) {
            this.harga = harga;
        }

        public String getWaktu() {
                return waktu;
            }



        public void setWaktu(String waktu) {
            this.waktu = waktu;
        }

        public String getTanggal() {
            return tanggal;
    }

        public void setTanggal(String tanggal) {
            this.tanggal = tanggal;
    }
    }