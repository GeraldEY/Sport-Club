package com.example.ujian;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class myadapter extends RecyclerView.Adapter<myadapter.MyViewHolder> {

    Context context;
    ArrayList<artikel> artikelArrayList;

    public myadapter(Context context, ArrayList<artikel> artikelArrayList) {

        this.context = context;
        this.artikelArrayList = artikelArrayList;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.artikel, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.gambar_artikel.setImageResource(artikelArrayList.get(position).getGambar_artikel());
        holder.judul_artikel.setText(artikelArrayList.get(position).getJudul_artikel());
        holder.isi_artikel.setText(artikelArrayList.get(position).getIsi_artikel());


        holder.itemView.setOnClickListener(e -> {
            Intent detail = new Intent(holder.itemView.getContext(), detail.class);
            detail.putExtra("gambar_artikel", artikelArrayList.get(position).gambar_artikel);
            detail.putExtra("judul_artikel", artikelArrayList.get(position).judul_artikel);
            detail.putExtra("isi_artikel", artikelArrayList.get(position).isi_artikel);
            detail.putExtra("lengkap_artikel", artikelArrayList.get(position).lengkap_artikel);
            e.getContext().startActivity(detail);
        });
    }

    @Override
    public int getItemCount() {
        return artikelArrayList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView gambar_artikel;
        private TextView judul_artikel, isi_artikel;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            gambar_artikel = itemView.findViewById(R.id.gambar_artikel);
            judul_artikel = itemView.findViewById(R.id.judul_artikel);
            isi_artikel = itemView.findViewById(R.id.isi_artikel);
        }
    }
}