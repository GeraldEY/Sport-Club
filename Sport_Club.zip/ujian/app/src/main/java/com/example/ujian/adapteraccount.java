package com.example.ujian;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adapteraccount extends RecyclerView.Adapter<adapteraccount.ViewHolder>{
    ArrayList<history>historyArrayList ;
    Context context;

    public adapteraccount(Context context, ArrayList<history> historyArrayList){
        this.context = context;
        this.historyArrayList = historyArrayList;
    }

    @NonNull
    @Override
    public adapteraccount.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull adapteraccount.ViewHolder holder, int position) {
        holder.title.setText(historyArrayList.get(position).getName());
        holder.date.setText(historyArrayList.get(position).getDate());
        holder.price.setText(historyArrayList.get(position).getPrice());
        holder.quantity.setText(String.valueOf(historyArrayList.get(position).getQuantity()));

        holder.delete.setOnClickListener(e->{
            historyArrayList.remove(historyArrayList.get(position));
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, getItemCount());
        });
    }

    @Override
    public int getItemCount() {
        return historyArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, date, price, quantity;
        Button delete;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.HeaderTransaction);
            date = itemView.findViewById(R.id.DateTransaction);
            price = itemView.findViewById(R.id.PriceTransaction);
            quantity = itemView.findViewById(R.id.QuantityTransaction);
            delete = itemView.findViewById(R.id.Delete);
        }
    }
}

