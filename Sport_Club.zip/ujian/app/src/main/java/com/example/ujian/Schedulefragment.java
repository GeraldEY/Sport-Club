package com.example.ujian;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class Schedulefragment extends Fragment {


        private ArrayList<Schedule> scheduleArrayList;
        private String[] tim1;
        private String[] tim2;
        private String[] waktu;
        private String [] harga;
        private String [] judul;

        private String[] tanggal;
        private int[] gambar_1;
        private int[] gambar_2;

        private RecyclerView recyclerView;


        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            return inflater.inflate(R.layout.fragment_schedulefragment, container, false);

        }

        @Override
        public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);

            datainitialize();
            recyclerView = view.findViewById(R.id.recyclerview);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            recyclerView.setHasFixedSize(true);
            adapterschedule adapterschedule = new adapterschedule(getContext(),scheduleArrayList);
            recyclerView.setAdapter(adapterschedule);
            adapterschedule.notifyDataSetChanged();

        }
        private void datainitialize () {
            scheduleArrayList = new ArrayList<>();


            gambar_1 = new int[]{
                    R.drawable.barcelona,
                    R.drawable.betis,
                    R.drawable.barcelona,

            };

            gambar_2 = new int[]{
                    R.drawable.espanyol,
                    R.drawable.barcelona,
                    R.drawable.osasuna,

            };

            tim1 = new String[]{
                    "Barcelona",
                    "Betis",
                    "Barcelona",
            };

            tim2 = new String[]{
                    "Espanyol",
                    "Barcelona",
                    "Osasuna",
            };

            tanggal = new String[]{
                    "Mon, 01/05/23",
                    "Wed, 03/05/23",
                    "Sat, 06/05/23",
            };

            waktu = new String[]{
                    "23.00",
                    "01.00",
                    "03.00",

            };

            harga = new String[]{
                    "100 Euro",
                    "110 Euro",
                    "120 Euro",
            };

            judul =  new String[]{
                    "Barcelona VS Espanyol",
                    "Betis VS Barcelona",
                    "Barcelona VS Osasuna",
            };


            for (int i = 0; i < tim1.length; i++){
                Schedule schedule = new Schedule(tim1[i],tim2[i],tanggal[i],waktu[i],judul[i],harga[i],gambar_1[i],gambar_2[i]);
                scheduleArrayList.add(schedule);
            }

        }
    }
