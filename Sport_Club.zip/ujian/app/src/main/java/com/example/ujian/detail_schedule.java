package com.example.ujian;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.shapes.Shape;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.imageview.ShapeableImageView;

public class detail_schedule extends AppCompatActivity {

    ShapeableImageView gambarschedule1,gambarschedule2;
    TextView schedulejudul,scheduleharga;
    TextView schedulewaktu,scheduletanggal;
    TextView quantity;
    Button buy,back;

    String Schedulejudul, Schedulewaktu, Scheduletanggal,Scheduleharga;
    Integer Gambarschedule1,Gambarschedule2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_schedule);

        Schedulejudul = getIntent().getStringExtra("judul");
        Schedulewaktu = getIntent().getStringExtra("waktu");
        Scheduletanggal = getIntent().getStringExtra("tanggal");
        Scheduleharga = getIntent().getStringExtra("harga");
        Gambarschedule1 = getIntent().getIntExtra("gambar_1", 0);
        Gambarschedule2 = getIntent().getIntExtra("gambar_2", 0);


        schedulejudul = findViewById(R.id.TitleDetail);
        schedulewaktu = findViewById(R.id.TimeDetail);
        scheduletanggal = findViewById(R.id.Description);
        scheduleharga = findViewById(R.id.PriceDetail);
        gambarschedule1 = findViewById(R.id.ImageDetail);
        gambarschedule2 = findViewById(R.id.ImageDetail2);
        back = findViewById(R.id.BacktoHome);


        schedulejudul.setText(Schedulejudul);
        schedulewaktu.setText(Schedulewaktu);
        scheduletanggal.setText(Scheduletanggal);
        scheduleharga.setText(Scheduleharga);
        gambarschedule1.setImageResource(Gambarschedule1);
        gambarschedule2.setImageResource(Gambarschedule2);

        quantity = findViewById(R.id.Quantity);
        buy = findViewById(R.id.Buy);
        buy.setOnClickListener(e->{
            if (quantity.getText().toString().isEmpty()){
                Toast.makeText(this, "Quantity must be filled", Toast.LENGTH_SHORT).show();
            } else if (Integer.valueOf(quantity.getText().toString()) <= 0) {
                Toast.makeText(this, "Quantity must be more than 1", Toast.LENGTH_SHORT).show();

            } else {
                home.historyArrayList.add(new history(Schedulejudul, Schedulewaktu,Scheduleharga, Integer.parseInt(quantity.getText().toString())));
                Toast.makeText(this, "Transaction sucsessfully update!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, home.class);
                intent.putExtra("Quantity", quantity.getText().toString());
                startActivity(intent);
            }
        });


        back = findViewById(R.id.BacktoHome);
        back.setOnClickListener(e->{
            Intent intent = new Intent(this, home.class);
            startActivity(intent);
        });
    }
}