package com.example.ujian;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class Homefragment extends Fragment {

    private ArrayList<artikel>artikelArrayList;
    private String[] judulartikel;
    private String[] isiartikel;

    private String[] lengkapartikel;
    private int[] gambarartikel;

    private RecyclerView recyclerView;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_homefragment, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        datainitialize();
        recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setHasFixedSize(true);
        myadapter myadapter = new myadapter(getContext(),artikelArrayList);
        recyclerView.setAdapter(myadapter);
        myadapter.notifyDataSetChanged();

    }
    private void datainitialize () {
        artikelArrayList = new ArrayList<>();


        gambarartikel = new int[]{
                R.drawable.gambar1,
                R.drawable.gambar2,
                R.drawable.gambar3,

        };

        judulartikel = new String[]{

                "Dikalahkan Rayo Vallecano, Barcelona Gagal Perlebar Jarak dengan Real Madrid",
                "Frustasi! Ter Stegen Curhat ke Reporter Usai Barcelona Gagal Menang dalam 3 Laga Beruntun",
                "Barcelona Keluar dari Tekanan, Ferran Torres Cetak Gol Kemenangan",
        };


        isiartikel = new String[]{
                "Barcelona gagal memperlebar jarak dengan Real Madrid setelah kalah 1-2 dari Rayo",
                "Sang penjaga gawang, Ter Stegen secara terang terangan menunjukkan rasa frustasinya ke awak media.",
                "Barcelona berhasil keluar dari tekanan. Ferran Torres cetak gol kemenangan atas Atletico Madrid",
        };

        lengkapartikel = new String[]{
                "Barcelona kembali membuang peluang. Kesempatan memperlebar jarak menjadi 14 poin atas Real Madrid gagal mereka manfaatkan menyusul kekalahan 1-2 atas Rayo Vallecano pekan ke-31 La Liga pada Rabu, 26 April 2023 waktu setempat. Kekalahan 2-4 Real Madrid atas Girona satu hari sebelumnya sejatinya merupakqn kabar baik bagi Barcelona. Kemenangan atas Rayo Vallecano akan memperlancar jalan mereka menuju tangga juara secepatnya. Apalagi mereka cukup diunggulkan. Sayang, kesempatan ini gagal dimanfaatkan Robert Lewandowski dan kawan-kawan. Perlawanan agresif  Rayo yang bertindak sebagai tuan rumah berhasil membuat Barcelona takluk.",
                "Barcelona baru saja mendapatkan hasil yang kurang baik setelah kembali ditahan imbang tanpa gol oleh Getafe dalam laga yang berlangsung di stadion Alfonso perez pada minggu (16/04) WIB.Raihan imbang tanpa gol menjadi raihan kedua kali secara beruntun yang didapatkan oleh La Blaugrana dalam dua laga terakhirnya di la liga. Secara keseluruhan Barcelona tidak meraih kemenangan sama sekali dalam tiga laga terakhir yang dijalani di semua kompetisi termasuk kekalahan telak 4-0 yang didapatkan atas Real Madrid di laga leg kedua babak semi final Copa Del Ray yang membuat anak asuh Xavi Hernandez tersingkir dari kompetisi tersebut.",
                "Barcelona berhasil keluar dari tekanan. Satu gol dari Ferran Torres memastikan kemenangan mereka atas Atletico Madrid pada Minggu, 23 April 2023 pekan ke-30 La Liga 2022/2023. Kemenangan ini sekaligus menjaga keunggulan 11 poin mereka sebagai pemuncak klasemen atas Real Madrid.\n" + "Barcelona berada dalam tekanan dalam beberapa minggu terakhir. Usai dihajar empat gol oleh Real Madrid pada leg kedua semifinal Copa del Rey awal bulan lalu, tim asuhan Xavi Hernandez ini gagal menunjukkan performa terbaik mereka. Dalam dua laga La Liga berikutnya melawan Girona dan Getafe, mereka gagal meraup kemenangan. Bahkan tanpa mencetak satu gol pun.Disisi lain, Real Madrid yang menjadi rival utama mereka terus memberi tekanan. Dua kemenangan atas Cadiz dan Celta Vigo berhasil memangkas jarak menjadi delapan poin saja. Meski jaraknya masih cukup jauh tapi tetap saja membuat khawatir para pendukung El Barca.",


        };



        for (int i = 0; i < judulartikel.length; i++){
            artikel artikel = new artikel(judulartikel[i],isiartikel[i],lengkapartikel[i],gambarartikel[i]);
            artikelArrayList.add(artikel);
        }

    }
}