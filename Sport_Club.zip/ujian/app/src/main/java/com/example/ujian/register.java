package com.example.ujian;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class register extends AppCompatActivity {
    EditText txtEmail, txtPass, txtPassConfirm;
    Button btnRegister, btnLogin;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DatabaseHelper(this);
        txtEmail = findViewById(R.id.regis_email);
        txtPass = findViewById(R.id.regis_pass);
        txtPassConfirm = findViewById(R.id.regis_confirm);
        btnRegister = findViewById(R.id.register_button);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = txtEmail.getText().toString();
                String password = txtPass.getText().toString();
                String passwordConfirm = txtPassConfirm.getText().toString();

                if (email.equals("") || password.equals("") || passwordConfirm.equals(""))
                    Toast.makeText(register.this, "All must be filled", Toast.LENGTH_SHORT).show();
                else {
                    if (password.equals(passwordConfirm)){
                        Boolean checkUserEmail= dbHelper.checkEmail(email);

                        if (checkUserEmail == false){
                            Boolean insert = dbHelper.insertData(email, password);

                            if (insert == true){
                                Toast.makeText(register.this, "Register Success", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), login.class);
                                startActivity(intent);
                            }else {
                                Toast.makeText(register.this, "Register Failed", Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            Toast.makeText(register.this, "User already exists, Please Login", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(register.this, "Password incorrect", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        btnLogin = findViewById(R.id.back_sign);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), login.class);
                startActivity(intent);
            }
        });
    }
}