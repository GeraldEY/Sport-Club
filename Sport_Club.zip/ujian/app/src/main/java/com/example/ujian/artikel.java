package com.example.ujian;

public class artikel {
        String judul_artikel,isi_artikel,lengkap_artikel;
        int gambar_artikel;

        public artikel(String judul_artikel,String isi_artikel,String lengkap_artikel,int gambar_artikel){
            this.judul_artikel = judul_artikel;
            this.isi_artikel = isi_artikel;
            this.lengkap_artikel = lengkap_artikel;
            this.gambar_artikel = gambar_artikel;



        }
        public String getJudul_artikel() {
            return judul_artikel;
        }

        public void setJudul_artikel(String judul_artikel) {
            this.judul_artikel = judul_artikel;
        }

        public int getGambar_artikel() {
            return gambar_artikel;
        }

        public void setGambar_artikel(int gambar_artikel) {
            this.gambar_artikel = gambar_artikel;
        }

        public String getIsi_artikel() {
            return isi_artikel;
        }

        public void setIsi_artikel(String isi_artikel) {
            this.isi_artikel = isi_artikel;
        }

        public String getLengkap_artikel() {
        return lengkap_artikel;
    }

        public void setLengkap_artikel(String lengkap_artikel) {
        this.lengkap_artikel = lengkap_artikel;
         }

}
