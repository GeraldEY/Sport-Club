package com.example.ujian;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adapterschedule extends RecyclerView.Adapter<adapterschedule.MyViewHolder>{
    Context context;
    ArrayList<Schedule>scheduleArrayList;

    public adapterschedule(Context context, ArrayList<Schedule>scheduleArrayList) {

        this.context = context;
        this.scheduleArrayList = scheduleArrayList;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_schedule, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.gambar_1.setImageResource(scheduleArrayList.get(position).getGambar_1());
        holder.gambar_2.setImageResource(scheduleArrayList.get(position).getGambar_2());
        holder.tim1.setText(scheduleArrayList.get(position).getTim1());
        holder.tim2.setText(scheduleArrayList.get(position).getTim2());
        holder.tanggal.setText(scheduleArrayList.get(position).getTanggal());
        holder.waktu.setText(scheduleArrayList.get(position).getWaktu());

        holder.itemView.setOnClickListener(e ->{
            Intent detail_schedule = new Intent(holder.itemView.getContext(), detail_schedule.class);
            detail_schedule.putExtra("gambar_1", scheduleArrayList.get(position).gambar_1);
            detail_schedule.putExtra("gambar_2" , scheduleArrayList.get(position).gambar_2);
            detail_schedule.putExtra("judul",scheduleArrayList.get(position).judul);
            detail_schedule.putExtra("tanggal",scheduleArrayList.get(position).tanggal);
            detail_schedule.putExtra("waktu",scheduleArrayList.get(position).waktu);
            detail_schedule.putExtra("harga",scheduleArrayList.get(position).harga);
            e.getContext().startActivity(detail_schedule);
        });


    }

    @Override
    public int getItemCount() {
        return scheduleArrayList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView gambar_1, gambar_2;
        private TextView tim1, tim2, waktu, tanggal;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            gambar_1 = itemView.findViewById(R.id.gambar_1);
            gambar_2 = itemView.findViewById(R.id.gambar_2);
            tim1 = itemView.findViewById((R.id.tim1));
            tim2 = itemView.findViewById((R.id.tim2));
            waktu = itemView.findViewById((R.id.waktu));
            tanggal = itemView.findViewById((R.id.tanggal));
        }
    }
}

