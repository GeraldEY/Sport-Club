package com.example.ujian;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class detail extends AppCompatActivity {
    ImageView detailgambar;
    TextView detaillengkap;
    TextView detailjudul;

    String detailJudul, detailLengkap;
    Integer detailGambar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        detailJudul = getIntent().getStringExtra("judul_artikel");
        detailLengkap = getIntent().getStringExtra("lengkap_artikel");
        detailGambar= getIntent().getIntExtra("gambar_artikel", 0);


        detailgambar = findViewById(R.id.detail_gambar);
        detailjudul = findViewById(R.id.detail_judul);
        detaillengkap = findViewById(R.id.detail_lengkap);


        detailgambar.setImageResource(detailGambar);
        detailjudul.setText(detailJudul);
        detaillengkap.setText(detailLengkap);
    }
}
