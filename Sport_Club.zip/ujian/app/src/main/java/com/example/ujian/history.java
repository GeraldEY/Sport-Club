package com.example.ujian;

public class history {
    String name, date, price;
    int quantity;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String time) {
        this.date = date;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public history(String name, String date, String price, int quantity) {
        this.name = name;
        this.date = date;
        this.price = price;
        this.quantity = quantity;
    }
}


